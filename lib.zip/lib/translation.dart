
import 'package:get/get.dart';
import 'translation_service.dart';

class AppTranslations extends Translations {
  static Map<String, String> storedTranslations = {};

  /// Load stored translations asynchronously before using the class
  static Future<void> initialize() async {
    storedTranslations = await TranslationService.loadStoredTranslations();
  }

  @override
  Map<String, Map<String, String>> get keys => {
    'en_US': {
      'welcome': 'Welcome',
      'menu': 'Menu',
      'change_language': 'Change Language',
      'select_language': 'Select Language',
      'settings': 'Settings',
      'about': 'About',
      'sign_to_text': 'Gestures to Voice & Text',
      'sign_to_text_desc': 'Convert sign language into text and speech.',
      'text_to_sign': 'Voice & Text to Gestures',
      'text_to_sign_desc': 'Convert text and speech into sign language.',
      'start_recording': 'Start Recording',
      'stop_recording': 'Stop Recording',
      'waiting_for_sign': 'Waiting for Sign',
      'play_voice_output': 'Play Voice Output',
      'sign_to_text_and_voice': 'Sign to Text and Voice',
      'tap_the_mic_to_speak': 'Tap the Mic to Speak',
      'speech_to_gesture_avatar': 'Speech to Gesture Avatar',
      'no_cameras_found': 'No cameras found',
      'error_initializing_camera': 'Error initializing camera',
      'processing_signs': 'Processing signs...',
      'recognized_sign': 'Recognized Sign: Hello',
      'speech_to_gesture_avatar': 'Speech to Gesture Avatar',
      'was_this_sign_easy_to_learn': 'Was this sign easy to learn?',
      'tap_the_mic_to_speak': 'Tap the mic to speak',
      "sign_to_text_and_voice": "Sign to Text and Voice",
      "waiting_for_sign": "Waiting for sign...",
      "processing_signs": "Processing signs...",
      "How This App Helps": "How This App Helps",
      "University Information": "University Information",
      "Supervisor": "Supervisor",
      'Waiting for sign...': 'Waiting for sign...',
      "Contact": "Contact",
      "1️⃣  Open the app and choose a module:\n"
          "   - Gestures ➝ Text/Voice\n"
          "   - Text/Voice ➝ Gestures\n\n"
          "2️⃣ If you are a deaf/mute user, show a hand gesture to the camera, "
          "and the app will translate it into text or voice.\n\n"
          "3️⃣ If you are a non-sign language user, speak or type a sentence, "
          "and the app will display a corresponding sign language video.\n\n"
          "4️⃣ Continue the conversation smoothly without barriers.":"1️⃣ Open the app and choose a module:\n"
          "   - Gestures ➝ Text/Voice\n"
          "   - Text/Voice ➝ Gestures\n\n"
          "2️⃣ If you are a deaf/mute user, show a hand gesture to the camera, "
          "and the app will translate it into text or voice.\n\n"
          "3️⃣ If you are a non-sign language user, speak or type a sentence, "
          "and the app will display a corresponding sign language video.\n\n"
          "4️⃣ Continue the conversation smoothly without barriers.",
      "failed_to_load_camera": "Failed to load camera",
      "start_recording": "Start Recording",
      "stop_recording": "Stop Recording",
      "play_voice_output": "Play Voice Output",
      "remove_letter": "Remove Last Letter",
      'Please perform the correct gesture': 'Please perform the correct gesture',
      'No gesture video exists for this phrase': 'No gesture video exists for this phrase',
      'Text/Speech to Gesture': 'Text/Speech to Gesture',
      'Enter text to convert to gesture': 'Enter text to convert to gesture',
      'Say something...': 'Say something...',
      'failed_to_load_camera': 'Failed to load camera',
      "Back Camera": "Back Camera",
      "Front Camera": "Front Camera"
    },
    'ur_PK': storedTranslations.isNotEmpty ? storedTranslations : {
      'welcome': 'خوش آمدید',
      'menu': 'مینو',
      'Please perform the correct gesture': 'براہ کرم صحیح اشارہ کریں',
      'change_language': 'زبان تبدیل کریں',
      'select_language': 'زبان منتخب کریں',
      'settings': 'ترتیبات',
      'About': 'کے بارے میں',
      'Logout':'لاگ آؤٹ',
      "Back Camera": "پیچھے والا کیمرہ",
      "Front Camera": "سامنے والا کیمرہ",
      'No gesture video exists for this phrase': 'اس جملے کے لیے کوئی اشارہ ویڈیو موجود نہیں',
      'Text/Speech to Gesture': 'ٹیکسٹ/آواز سے اشارہ',
      'Enter text to convert to gesture': 'اشارہ بنانے کے لیے متن درج کریں',
      'Say something...': 'کچھ بولیں...',
      'sign_to_text': 'اشاروں کو آواز اور متن میں تبدیل کریں',
      'sign_to_text_desc': 'اشاروں کی زبان کو متن اور تقریر میں تبدیل کریں۔',
      'text_to_sign': 'آواز اور متن کو اشاروں میں تبدیل کریں',
      'text_to_sign_desc': 'متن اور تقریر کو اشاروں میں تبدیل کریں۔',
      'start_recording': 'ریکارڈنگ شروع کریں',
      'stop_recording': 'ریکارڈنگ بند کریں',
      'waiting_for_sign': 'اشارے کا انتظار ہو رہا ہے',
      'play_voice_output': 'آواز چلائیں',
      'sign_to_text_and_voice': 'اشارے کو متن اور آواز میں تبدیل کریں',
      'tap_the_mic_to_speak': 'بولنے کے لیے مائیکروفون کو چھوئیں',
      'speech_to_gesture_avatar': 'تقریر کو اشارے میں تبدیل کرنے والا اوتار',
      "About Deaftalk": "ڈیف ٹاک کے بارے میں",
      "How This App Helps": "یہ ایپ کیسے مدد کرتی ہے",
      "1️⃣ Open the app and choose a module:\n"
          "   - Gestures ➝ Text/Voice\n"
          "   - Text/Voice ➝ Gestures\n\n"
          "2️⃣ If you are a deaf/mute user, show a hand gesture to the camera, "
          "and the app will translate it into text or voice.\n\n"
          "3️⃣ If you are a non-sign language user, speak or type a sentence, "
          "and the app will display a corresponding sign language video.\n\n"
          "4️⃣ Continue the conversation smoothly without barriers.": "1️⃣ ایپ کھولیں اور ایک ماڈیول منتخب کریں:\n   - اشارے ➝ متن / آواز\n   - متن / آواز ➝ اشارے\n\n2️⃣ اگر آپ بہرے یا گونگے صارف ہیں تو کیمرے کے سامنے ہاتھ کا اشارہ دکھائیں، اور ایپ اسے متن یا آواز میں تبدیل کرے گی۔\n\n3️⃣ اگر آپ غیر اشارہ زبان استعمال کرنے والے ہیں تو ایک جملہ بولیں یا لکھیں، اور ایپ متعلقہ اشارہ زبان کی ویڈیو دکھائے گی۔\n\n4️⃣ بات چیت کو آسانی سے بغیر کسی رکاوٹ کے جاری رکھیں۔",
      "University Information": "جامعہ کی معلومات",
      "Supervisor": "نگران",
      "Contact": "رابطہ",
      'hello': 'ہیلو',
      'yes': 'ہاں',
      'no': 'نہیں',
      "Ahmad": "احمد",
      "Irum": "ارم",
      "Saad": "سعد",
      "Rida": "ردا",
      "Sara": "سارا",
      "Alif": "الف",
      "Bay": "ب",
      "Pay": "پ",
      "Tay": "ت",
      "Ttay": "ٹ",
      "Say": "ث",
      "Jeem": "ج",
      "Chay": "چ",
      "Hay": "ح",
      "Khay": "خ",
      "Dal": "د",
      "Ddal": "ڈ",
      "Zal": "ذ",
      "Ray": "ر",
      "Rray": "ڑ",
      "Zay": "ز",
      "Seen": "س",
      "Sheen": "ش",
      "Suad": "ص",
      "Zuad": "ض",
      "Toe": "ط",
      "Zoey": "ظ",
      "Ain": "ع",
      "Ghain": "غ",
      "Fay": "ف",
      "Qaaf": "ق",
      "Kaaf": "ک",
      "Gaaf": "گ",
      "Laam": "ل",
      "Meem": "م",
      "Noon": "ن",
      "Wow": "و",
      "Hey": "ہ",
      "ChotiYay": "ی",
      "BariYay": "ے",
      "AlifMadda": "آ",
      "AlifHamza": "ء",
      'goodbye': 'الوداع',
      'thank_you': 'شکریہ',
      "Remove Letter": "آخری حرف ہٹائیں",
      "remove_word": "آخری لفظ ہٹائیں",
      'settings': 'ترتیبات',
      'about': 'کے بارے میں','sign_to_text': 'اشاروں کو آواز اور متن میں تبدیل کریں',
      'sign_to_text_desc': 'اشاروں کی زبان کو متن اور تقریر میں تبدیل کریں۔',
      'text_to_sign': 'آواز اور متن کو اشاروں میں تبدیل کریں',
      'text_to_sign_desc': 'متن اور تقریر کو اشاروں میں تبدیل کریں۔',
      'start_recording': 'ریکارڈنگ شروع کریں',
      'stop_recording': 'ریکارڈنگ بند کریں',
      'play_voice_output': 'آواز چلائیں',
      'waiting_for_sign': 'اشارے کا انتظار ہو رہا ہے',
      'processing_signs': 'اشاروں پر کارروائی ہو رہی ہے...',
      'recognized_sign': 'پہچانا گیا اشارہ:',
      'Waiting for sign...': 'اشارے کا انتظار ہو رہا ہے...',
      'Text/Speech to Gesture': 'متن/آواز کو اشاروں میں تبدیل کریں',
      'Waiting for input...': 'ان پٹ کے انتظار میں...',
      'Enter text to convert to gesture': 'اشارے میں تبدیل کرنے کے لیے متن درج کریں',
      'Say something...': 'کچھ بولیں...',
      'speech_to_gesture_avatar': 'تقریر کو اشارے میں تبدیل کرنے والا اوتار',
      'was_this_sign_easy_to_learn': 'کیا یہ اشارہ سیکھنا آسان تھا؟',
      'tap_the_mic_to_speak': 'بولنے کے لیے مائیکروفون کو چھوئیں',
      'failed_to_load_camera': 'کیمرہ لوڈ کرنے میں ناکام',
      'remove_letter': 'آخری حرف حذف کریں',
      'remove_word': 'لفظ حذف کریں',
      'i_love_you': 'میں تم سے محبت کرتا ہوں',
      'no_cameras_found': 'کوئی کیمرہ نہیں ملا',
      'error_initializing_camera': 'کیمرہ شروع کرنے میں خرابی',
      'processing_signs': 'اشاروں پر کارروائی ہو رہی ہے...',
      'recognized_sign': 'پہچانا گیا اشارہ: ہیلو',
      'speech_to_gesture_avatar': 'تقریر کو اشارے میں تبدیل کرنے والا اوتار',
      'was_this_sign_easy_to_learn': 'کیا یہ اشارہ سیکھنا آسان تھا؟',
      'tap_the_mic_to_speak': 'بولنے کے لیے مائیکروفون کو چھوئیں',
      'say_something': 'کچھ بولیں',
      'failed_to_load_camera': 'کیمرہ لوڈ کرنے میں ناکام',
      'About App': 'ایپ کے بارے میں',
      'About DeafTalk': ' ڈیف ٹاک کے بارے میں',
      'DeafTalk is a mobile application designed to facilitate two-way communication between deaf/mute individuals and non-sign language users. It uses gesture recognition, speech processing, and video-based sign language to create a seamless communication bridge.':
      'ڈیف ٹاک ایک موبائل ایپ ہے جو گونگے اور بہرے افراد اور غیر اشارتی زبان استعمال کرنے والوں کے درمیان دو طرفہ رابطے کو آسان بنانے کے لیے بنائی گئی ہے۔ یہ اشاروں کی پہچان، تقریر کی پروسیسنگ، اور ویڈیو پر مبنی اشارتی زبان استعمال کرتی ہے تاکہ آسان رابطہ فراہم کیا جا سکے۔',

      ' How This App Helps': ' یہ ایپ کیسے مدد کرتی ہے',
      '✔ Makes communication easier between deaf/mute individuals and others.\n✔ Reduces dependency on human interpreters.\n✔ Helps in daily conversations such as greetings, asking questions, and expressing needs.\n✔ Encourages inclusivity in education, workplaces, and social interactions.':
      '✔ گونگے اور بہرے افراد اور دوسروں کے درمیان رابطہ آسان بناتی ہے۔\n✔ انسانی مترجموں پر انحصار کم کرتی ہے۔\n✔ روزمرہ بات چیت جیسے سلام، سوالات، اور ضروریات کے اظہار میں مدد دیتی ہے۔\n✔ تعلیم، کام کی جگہوں، اور معاشرتی روابط میں شمولیت کو فروغ دیتی ہے۔',

      ' How to Use DeafTalk': ' ڈیف ٹاک استعمال کرنے کا طریقہ',
      ' Open the app and choose a module:\n   - Gestures ➝ Text/Voice\n   - Text/Voice ➝ Gestures\n\n If you are a deaf/mute user, show a hand gesture to the camera, and the app will translate it into text or voice.\n\n If you are a non-sign language user, speak or type a sentence, and the app will display a corresponding sign language video.\n\n Continue the conversation smoothly without barriers.':
      ' ایپ کھولیں اور ایک ماڈیول منتخب کریں:\n   - اشارے ➝ متن/آواز\n   - متن/آواز ➝ اشارے\n\n اگر آپ گونگے یا بہرے صارف ہیں تو کیمرے کے سامنے ہاتھ کا اشارہ دکھائیں، ایپ اسے متن یا آواز میں تبدیل کرے گی۔\n\n اگر آپ غیر اشارتی زبان کے صارف ہیں تو بولیں یا جملہ لکھیں، اور ایپ متعلقہ اشارتی ویڈیو دکھائے گی۔\n\n بغیر کسی رکاوٹ کے بات چیت جاری رکھیں۔',

      ' Why This App is Needed': ' یہ ایپ کیوں ضروری ہے',
      'Millions of deaf and mute individuals face challenges in everyday communication because many people do not understand sign language. Existing solutions often require human interpreters, which are not always available. DeafTalk solves this problem by providing a digital communication bridge that works anytime, anywhere.':
      'لاکھوں گونگے اور بہرے افراد روزمرہ گفتگو میں مشکلات کا سامنا کرتے ہیں کیونکہ زیادہ تر لوگ اشارتی زبان نہیں سمجھتے۔ موجودہ حل عام طور پر انسانی مترجموں پر منحصر ہیں جو ہمیشہ دستیاب نہیں ہوتے۔ ڈیف ٹاک اس مسئلے کو ایک ڈیجیٹل رابطے کے پل کے ذریعے حل کرتی ہے جو کسی بھی وقت اور کہیں بھی کام کرتا ہے۔',

      'University Information': ' جامعہ کی معلومات',
      'University: National University of Modern Languages (NUML)': 'یونیورسٹی: نیشنل یونیورسٹی آف ماڈرن لینگویجز (نمل)',
      'Department: Computer Science': 'شعبہ: کمپیوٹر سائنس',

      'Supervisor': ' نگران',
      'Name: Miss Makia Nazir': 'نام: مس مکیا نذیر',
      'Designation: Lecturer': 'عہدہ: لیکچرار',

      'Team Members': ' ٹیم کے اراکین',
      '1. Muntaha Asif': '1. منتہا آصف',
      '2. Faiza Aziz': '2. فائزہ عزیز',
      '3. Muqadas Javed': '3. مقدس جاوید',

      'Contact': ' رابطہ',
      'Email: team@example.com': 'ای میل: team@example.com',
      'Version: 1.0.0': 'ورژن: 1.0.0',

    },
  };

  ///  Get Translation Dynamically
  Future<String> getTranslation(String key, String languageCode) async {
    if (keys[languageCode]?.containsKey(key) ?? false) {
      return keys[languageCode]![key]!; //  manual translations
    } else {
      return await TranslationService.fetchTranslation(key, languageCode); // Fetch from API
    }
  }
}

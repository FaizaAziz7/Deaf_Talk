import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:  Text("About App".tr),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding:  EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // App Logo or Icon
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.green.shade100,
                child:  Icon(
                  Icons.sign_language,
                  size: 60,
                  color: Colors.green,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // App Description
            Text(
              "About DeafTalk".tr,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              "DeafTalk is a mobile application designed to facilitate two-way "
                  "communication between deaf/mute individuals and non-sign language users. "
                  "It uses gesture recognition, speech processing, and video-based sign "
                  "language to create a seamless communication bridge.".tr,
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.justify,
            ),

            const Divider(height: 30, thickness: 1),

            // How it helps
            Text(
              "How This App Helps".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              "✔ Makes communication easier between deaf/mute individuals and others.\n"
                  "✔ Reduces dependency on human interpreters.\n"
                  "✔ Helps in daily conversations such as greetings, asking questions, and expressing needs.\n"
                  "✔ Encourages inclusivity in education, workplaces, and social interactions.".tr,
              style: TextStyle(fontSize: 16),
            ),

            const Divider(height: 30, thickness: 1),

            // How to use
            Text(
              " How to Use DeafTalk".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              "1️⃣ Open the app and choose a module:\n"
                  "   - Gestures ➝ Text/Voice\n"
                  "   - Text/Voice ➝ Gestures\n\n"
                  "2️⃣ If you are a deaf/mute user, show a hand gesture to the camera, "
                  "and the app will translate it into text or voice.\n\n"
                  "3️⃣ If you are a non-sign language user, speak or type a sentence, "
                  "and the app will display a corresponding sign language video.\n\n"
                  "4️⃣ Continue the conversation smoothly without barriers.".tr,
              style: TextStyle(fontSize: 16),
            ),

            const Divider(height: 30, thickness: 1),

            // Why needed
            Text(
              " Why This App is Needed".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              "Millions of deaf and mute individuals face challenges in everyday communication "
                  "because many people do not understand sign language. Existing solutions often require "
                  "human interpreters, which are not always available. DeafTalk solves this problem by "
                  "providing a digital communication bridge that works anytime, anywhere.".tr,
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.justify,
            ),

            const Divider(height: 30, thickness: 1),

            // University Information
            Text(
              "University Information".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text("University: National University of Modern Languages (NUML)".tr),
            Text("Department: Computer Science".tr),

            const Divider(height: 30, thickness: 1),

            // Supervisor
            Text(
              "Supervisor".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text("Name: Miss Makia Nazir".tr),
            Text("Designation: Lecturer".tr),

            const Divider(height: 30, thickness: 1),

            // Team Members
            Text(
              "Team Members".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text("1. Muntaha Asif".tr),
            Text("2. Faiza Aziz".tr),
            Text("3. Muqadas Javed".tr),

            const Divider(height: 30, thickness: 1),

            // Contact
            Text(
              "Contact".tr,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text("Email: team@example.com".tr),
            Text("Version: 1.0.0".tr),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
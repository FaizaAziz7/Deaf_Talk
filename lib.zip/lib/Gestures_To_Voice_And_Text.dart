
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class SignToVoicePage extends StatefulWidget {
  const SignToVoicePage({super.key});

  @override
  _SignToVoicePageState createState() => _SignToVoicePageState();
}

class _SignToVoicePageState extends State<SignToVoicePage> {
  CameraController? _cameraController;
  CameraDescription? _selectedCamera;//currently selected camera
  final FlutterTts _flutterTts = FlutterTts();
  String recognizedText = "waiting_for_sign".tr;
  String displayUrdu = "";
  late Future<void> _cameraFuture;
  bool _isProcessing = false;

  String _sequence = "";
  String _lastUrduToSpeak = "";

  final String apiUrl = "https://maryann-scarabaeoid-drake.ngrok-free.dev/predict";
  final Map<String, Map<String, String>> nameMap = {
    "alif hay meem dal": {"key": "Ahmad", "urdu": "احمد"},
    "alif ray meem": {"key": "Irum", "urdu": "ارم"},
    "seen ain daal": {"key": "Saad", "urdu": "سعد"},
    "ray dal alif": {"key": "Rida", "urdu": "ردا"},
    "seen alif ray alif": {"key": "Sara", "urdu": "سارا"},
    "ain lam ya": {"key": "Ali", "urdu": "علی"},
    "alif ya meem noon": {"key": "Aiman", "urdu": "ایمن"},
    "alif seen dal": {"key": "Asad", "urdu": "اسد"},
    "alif noon waw alif ray": {"key": "Anwar", "urdu": "انوار"},
    "alif ray seen lam alif noon": {"key": "Arslan", "urdu": "ارسلان"},
    "alif waw ya seen": {"key": "Owais", "urdu": "اویس"},
    "bay lam ya": {"key": "Cat (Billi)", "urdu": "بلی"},
    "alif lam waw": {"key": "Owl (Ullu)", "urdu": "الو"},
    "hay ray noon": {"key": "Deer (Hiran)", "urdu": "ہرن"},
    "bay kaf ray ya": {"key": "Goat (Bakri)", "urdu": "بکری"},
    "kaf waw alif": {"key": "Crow (Kawa)", "urdu": "کوا"},
    "bay tay khe": {"key": "Duck (Batakh)", "urdu": "بطخ"},
    "gaf dal haa alif": {"key": "Donkey (Gadha)", "urdu": "گدھا"},
    "khe ray gaf waw sheen": {"key": "Rabbit (Khargosh)", "urdu": "خرگوش"},
    "meem waw ray": {"key": "Peacock (Mor)", "urdu": "مور"},
    "qaf lam meem": {"key": "Pen (Qalam)", "urdu": "قلم"},
    "kaf tay alif bay": {"key": "Book (Kitab)", "urdu": "کتاب"},
    "kaf pay": {"key": "Cup (Cup)", "urdu": "کپ"},
    "gaf hay ray dal ya": {"key": "Watch (Ghadi)", "urdu": "گھڑی"},
    "bay ya gaf": {"key": "Bag (Bag)", "urdu": "بیگ"},
    "gaf lam alif seen": {"key": "Glass (Glass)", "urdu": "گلاس"},
    "dal ray waw zay haa": {"key": "Door (Darwaza)", "urdu": "دروازہ"},
    "chay meem chay": {"key": "Spoon (Chamach)", "urdu": "چمچ"},
    "jeem waw tay alif": {"key": "Shoe (Joota)", "urdu": "جوتا"},
    "jeem ray alif bay": {"key": "Sock (Juraab)", "urdu": "جراب"},
    "bay alif lam tay ya": {"key": "Bucket (Balti)", "urdu": "بالٹی"},
    "swad waw fe alif": {"key": "Sofa (Sofa)", "urdu": "صوفہ"},
    "pay lam noon gaf": {"key": "Bed (Pilang)", "urdu": "پلنگ"},
    "tay kaf ya hay": {"key": "Pillow (Takiya)", "urdu": "تکیہ"},
    "pay khe waw lam": {"key": "Flower (Phool)", "urdu": "پھول"},
    "dal ray khe tay": {"key": "Tree (Darakht)", "urdu": "درخت"},
    "pay alif noon ya": {"key": "Water (Pani)", "urdu": "پانی"},
    "meem ttay ya": {"key": "Soil (Mitti)", "urdu": "مٹی"},
    "haa waw alif": {"key": "Air (Hawa)", "urdu": "ہوا"},
  };

  final Map<String, String> urduLetters = {
    "alif": "ا",
    "bay": "ب",
    "pay": "پ",
    "tay": "ت",
    "ttay": "ٹ",
    "jeem": "ج",
    "chay": "چ",
    "hay": "ح",
    "khe": "خ",
    "dal": "د",
    "dhal": "ذ",
    "ray": "ر",
    "zay": "ز",
    "seen": "س",
    "sheen": "ش",
    "swad": "ص",
    "zwad": "ض",
    "ain": "ع",
    "gain": "غ",
    "fe": "ف",
    "qaf": "ق",
    "kaf": "ک",
    "lam": "ل",
    "meem": "م",
    "noon": "ن",
    "waw": "و",
    "haa": "ہ",
    "hamza": "ء",
    "ya": "ی",
  };

  final List<String> validLetters = [
    "alif","bay","pay","tay","ttay","jeem","chay","hay","khe","dal","dhal",
    "ray","zay","seen","sheen","swad","zwad","ain","gain","fe","qaf","kaf",
    "lam","meem","noon","waw","haa","hamza","ya",
  ];

  @override
  void initState() {
    super.initState();
    _cameraFuture = _initializeCamera();
    _flutterTts.setLanguage("ur-PK");
  }

  // Initialize camera with choice of front/back
  Future<void> _initializeCamera({CameraLensDirection direction = CameraLensDirection.back}) async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) throw Exception("no_cameras_found".tr);

      _selectedCamera = cameras.firstWhere(
            (cam) => cam.lensDirection == direction,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(_selectedCamera!, ResolutionPreset.medium);
      await _cameraController?.initialize();
      if (mounted) setState(() {});
    } catch (e) {
      print("Camera error: $e");
    }
  }

  Future<void> _speakText() async {
    final textToSpeak = _lastUrduToSpeak.isNotEmpty ? _lastUrduToSpeak : recognizedText;
    await _flutterTts.speak(textToSpeak);
  }

  Future<void> _sendFrameToServer() async {
    if (_cameraController == null) return;
    try {
      final picture = await _cameraController!.takePicture();
      var request = http.MultipartRequest("POST", Uri.parse(apiUrl));
      request.files.add(await http.MultipartFile.fromPath("file", picture.path));
      var response = await request.send();
      var resBody = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        final data = json.decode(resBody);
        if (data["predictions"] != null && data["predictions"].isNotEmpty) {
          final best = data["predictions"][0];
          String detected = (best['label'] ?? "").toString().trim().toLowerCase();

          if (detected.isEmpty) return;

          if (!validLetters.contains(detected)) {
            setState(() {
              recognizedText = "Please perform the correct gesture".tr;
              displayUrdu = "";
            });
            return;
          }

          _sequence = _sequence.isEmpty ? detected : "${_sequence.trim()} $detected";

          bool isUrduMode = Get.locale?.languageCode == 'ur';

          String lookup = _sequence.trim();
          if (nameMap.containsKey(lookup)) {
            final entry = nameMap[lookup]!;
            setState(() {
              recognizedText = isUrduMode ? entry['urdu']! : entry['key']!;
              displayUrdu = isUrduMode ? entry['urdu']! : entry['key']!;
            });
            _lastUrduToSpeak = entry['urdu'] ?? entry['key']!;
            await _flutterTts.speak(_lastUrduToSpeak);
            _sequence = "";
          } else {
            List<String> letters = lookup.split(" ");
            String urduWord = letters.map((l) => urduLetters[l] ?? "").join();

            setState(() {
              if (isUrduMode) {
                recognizedText = urduWord;
                displayUrdu = "";
              } else {
                recognizedText = lookup;
                displayUrdu = "";
              }
            });

            final tokens = _sequence.split(' ');
            if (tokens.length > 6) {
              tokens.removeAt(0);
              _sequence = tokens.join(' ');
            }
          }
        }
      }
    } catch (e) {
      print("Error sending frame: $e");
    }
  }


  void _removeLastLetter() {
    if (_sequence.isEmpty) return;

    final tokens = _sequence.split(' ');
    tokens.removeLast();
    _sequence = tokens.join(' ');
    recognizedText = _sequence;
    displayUrdu = _sequence;

    setState(() {});
  }



  void _startProcessing() {
    if (_isProcessing) return;
    setState(() {
      _isProcessing = true;
      recognizedText = "processing_signs".tr;
      _sequence = "";
      _lastUrduToSpeak = "";
      displayUrdu = "";
    });
    _processLoop();
  }

  void _processLoop() async {
    while (_isProcessing) {
      await _sendFrameToServer();
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void _stopProcessing() {
    setState(() {
      _isProcessing = false;
      recognizedText = "waiting_for_sign".tr;
      displayUrdu = "";
    });
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isUrduMode = Get.locale?.languageCode == 'ur';

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // App bar
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20),
            color: Colors.green,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      "sign_to_text_and_voice".tr,
                      style: const TextStyle(color: Colors.white, fontSize: 24),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Camera selection buttons
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _cameraController?.dispose();
                    _initializeCamera(direction: CameraLensDirection.back);
                  },
                  child: Text("Back Camera".tr),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    _cameraController?.dispose();
                    _initializeCamera(direction: CameraLensDirection.front);
                  },
                  child: Text("Front Camera".tr),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                ),
              ],
            ),
          ),

          // Camera preview
          Expanded(
            flex: 5,
            child: FutureBuilder<void>(
              future: _cameraFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return _cameraController != null && _cameraController!.value.isInitialized
                      ? Container(
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.green, width: 5),
                    ),
                    clipBehavior: Clip.hardEdge,
                    child: CameraPreview(_cameraController!),
                  )
                      : Center(
                      child: Text("failed_to_load_camera".tr,
                          style: const TextStyle(color: Colors.green)));
                } else {
                  return const Center(
                      child: CircularProgressIndicator(color: Colors.green));
                }
              },
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(4),
            child: Text(
              recognizedText,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Colors.green, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),

          const SizedBox(height: 10),

          // Buttons row
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding:
                  const EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: _isProcessing ? _stopProcessing : _startProcessing,
                child: Text(
                    _isProcessing ? "stop_recording".tr : "start_recording".tr),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding:
                  const EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: _removeLastLetter,
                child: Text("Remove Letter".tr),
              ),
            ],
          ),

          const SizedBox(height: 10),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
              padding:
              const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
            ),
            onPressed: _speakText,
            child: Text("play_voice_output".tr),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

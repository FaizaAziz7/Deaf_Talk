import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:video_player/video_player.dart';
import 'package:string_similarity/string_similarity.dart';

class SpeechToGestureScreen extends StatefulWidget {
  const SpeechToGestureScreen({super.key});

  @override
  SpeechToGestureScreenState createState() => SpeechToGestureScreenState();
}

class SpeechToGestureScreenState extends State<SpeechToGestureScreen> {
  final stt.SpeechToText _speechToText = stt.SpeechToText();
  final TextEditingController _textController = TextEditingController();
  final _recognizedText = "".obs;

  bool isListening = false;

  VideoPlayerController? _controller;
  bool _isVideoReady = false;

  // Message for UI
  String uiMessage = "Waiting for sign...".tr;

  // Urdu → English Dictionary
  final Map<String, String> urduToEnglish = {
    "ٹھیک": "fine",
    "کھانا": "food",
    "اچھا": "good",
    "ہیلو": "hello",
    "آپ کیسے ہیں": "how are you",
    "اپ کیسے ہیں": "how are you",
    "میں بیمار ہوں": "i am sick",
    "میں طالب علم ہوں": "i am a student",
    "میں سائن لینگویج سیکھ رہا ہوں": "i am learning sign language",
    "میں واپس آؤں گا": "i will be back soon",
    "آپ کا نام کیا ہے": "what is your name",
    "اپ کا نام کیا ہے": "what is your name",
    "کیا": "what",
    "کون": "who",
    "کیوں": "why",
    "ہاں": "yes",
    "نہیں": "no",
    "پانی": "water",
    "شکریہ": "thanks",
    "باہر": "outside",
    "اندر": "inside",
    "خوبصورت": "beautiful",
    "پیارا": "cute",
    "ہم": "we",
    "بھائی": "brother",
    "بہن": "sister",
    "میں مدد کیسے کرسکتا ہوں": "how can i help you",
    "آپ کیسا محسوس کرتے ہیں": "how do you feel",
    "مجھے اس پر یقین نہیں ہے": "i do not believe this",
    "مجھے یہ پسند نہیں": "i do not like this",
    "میں نہیں سمجھا": "i do not understand",
    "تم": "you",
    "کیا یہ ٹوٹا ہوا ہے": "is it broken",
    "ایمبولینس بُلاو": "call the ambulance",
    "ایمبولینس بُلاوں": "call the ambulance",
    "کیا یہ سچ ہے": "is it True",
    "معاف کیجئے": "Excuse me",
    "چھوئو مت": "Don't Touch",
    "آپ کا دن اچھا گزرے": "Have a nice day",
    "صبح": "morning",
    "بعد": "after",
    "شام": "evening",
    "دوبارہ": "again",
    "عورت": "she",
    "مرد": "he",
    "سب": "all",
    "ہمیشہ": "always",
    "ایک جیسے": "same",
    "آو": "come",
    "چاہیے": "want",
    "یہ ٹھیک ہے": "it is fine",
    "ٹھیک ہے": "ok",
    "تو": "so",
    "کب": "when",
    "ا": "alif",
    "ب": "bay",
    "پ": "peh",
    "ت": "tey",
    "ٹ": "ttey",
    "ث": "sey",
    "ج": "jeem",
    "چ": "chey",
    "ح": "hha",
    "خ": "khey",
    "د": "daal",
    "ذ": "zaal",
    "ر": "rey",
    "ز": "zey",
    "ژ": "zhey",
    "ڑ": "arey",
    "س": "seen",
    "ش": "sheen",
    "ص": "suad",
    "ض": "zuad",
    "ط": "tuay",
    "ظ": "zuey",
    "ع": "ain",
    "غ": "ghaen",
    "ف": "fey",
    "ق": "kaafdots",
    "ک": "kaaf",
    "گ": "ghaf",
    "ل": "laam",
    "م": "meem",
    "ن": "noon",
    "ں": "noonGhunna",
    "و": "wao",
    "ہ": "golhey",
    "ء": "hamza",
    "ی": "yay",
    "ے": "bariyay",
    "ی": "chotiyay",
  };

  // Gesture Videos
  final Map<String, String> gestureVideos = {
    "fine": "assets/Videos/fine.mp4",
    "food": "assets/Videos/food.mp4",
    "good": "assets/Videos/good.mp4",
    "hello": "assets/Videos/hello1.mp4",
    "how can i help you": "assets/Videos/howcanIhelpu.mp4",
    "how do you feel": "assets/Videos/howdoUfeel.mp4",
    "how are you": "assets/Videos/HowRU1.mp4",
    "i do not believe this": "assets/Videos/Idontbelievethis.mp4",
    "i": "assets/Videos/I.mp4",
    "i do not like this": "assets/Videos/Idontlikethis.mp4",
    "i do not understand": "assets/Videos/Idontunderstand.mp4",
    "i am learning sign language": "assets/Videos/IMlearningSignlang.mp4",
    "i am sick": "assets/Videos/IMsick.mp4",
    "i am a student": "assets/Videos/IMstudent.mp4",
    "no": "assets/Videos/no.mp4",
    "are you deaf": "assets/Videos/RUdeaf.mp4",
    "are you hungry": "assets/Videos/RUhungry.mp4",
    "thanks": "assets/Videos/Thanks.mp4",
    "want": "assets/Videos/want.mp4",
    "water": "assets/Videos/water.mp4",
    "what": "assets/Videos/what.mp4",
    "what is your name": "assets/Videos/WhatURName.mp4",
    "when": "assets/Videos/when.mp4",
    "who": "assets/Videos/who.mp4",
    "why": "assets/Videos/why.mp4",
    "yes": "assets/Videos/yes.mp4",
    "you": "assets/Videos/you.mp4",
    "come": "assets/Videos/come.mp4",
    "morning": "assets/Videos/morning.mp4",
    "after": "assets/Videos/after.mp4",
    "evening": "assets/Videos/evening.mp4",
    "again": "assets/Videos/again.mp4",
    "she": "assets/Videos/she.mp4",
    "he": "assets/Videos/he.mp4",
    "all": "assets/Videos/all.mp4",
    "outside": "assets/Videos/outside.mp4",
    "inside": "assets/Videos/inside.mp4",
    "it is fine": "assets/Videos/itsFine.mp4",
    "i will be back soon": "assets/Videos/illBeBacksoon.mp4",
    "always": "assets/Videos/always.mp4",
    "cute": "assets/Videos/cute.mp4",
    "beautiful": "assets/Videos/beautiful.mp4",
    "ok": "assets/Videos/ok.mp4",
    "so": "assets/Videos/so.mp4",
    "sister": "assets/Videos/sister.mp4",
    "brother": "assets/Videos/brother.mp4",
    "we": "assets/Videos/we.mp4",
    "same": "assets/Videos/same.mp4",
    "is it broken": "assets/Videos/isItBroken.mp4",
    "call the ambulance": "assets/Videos/callTheAmbulance.mp4",
    "is it True": "assets/Videos/isItTrue.mp4",
    "Excuse me": "assets/Videos/excuseMe.mp4",
    "Don't Touch": "assets/Videos/dontTouch.mp4",
    "Have a nice day": "assets/Videos/haveAniceDay.mp4",
    "alif": "assets/Videos/alif.mp4",
    "bay": "assets/Videos/bey.mp4",
    "peh": "assets/Videos/pey.mp4",
    "tey": "assets/Videos/tey.mp4",
    "ttey": "assets/Videos/ttey.mp4",
    "sey": "assets/Videos/Sey.mp4",
    "jeem": "assets/Videos/jeem.mp4",
    "chey": "assets/Videos/chey.mp4",
    "hha": "assets/Videos/hey.mp4",
    "khey": "assets/Videos/khey.mp4",
    "daal": "assets/Videos/daal.mp4",
    "zaal": "assets/Videos/zaal.mp4",
    "rey": "assets/Videos/rey.mp4",
    "arey": "assets/Videos/arey.mp4",
    "zey": "assets/Videos/zey.mp4",
    "zhey": "assets/Videos/zhey.mp4",
    "seen": "assets/Videos/seen.mp4",
    "sheen": "assets/Videos/sheen.mp4",
    "suad": "assets/Videos/suad.mp4",
    "zuad": "assets/Videos/zuad.mp4",
    "tuay": "assets/Videos/tuey.mp4",
    "zuey": "assets/Videos/zuey.mp4",
    "ain": "assets/Videos/ain.mp4",
    "ghaf": "assets/Videos/ghaf.mp4",
    "fey": "assets/Videos/fey.mp4",
    "kaafdots": "assets/Videos/kaafdots.mp4",
    "kaaf": "assets/Videos/kaaf.mp4",
    "gaen": "assets/Videos/gaen.mp4",
    "laam": "assets/Videos/laam.mp4",
    "meem": "assets/Videos/meem.mp4",
    "noon": "assets/Videos/noon.mp4",
    "noonGhunna": "assets/Videos/noonGhunna.mp4",
    "wao": "assets/Videos/wao.mp4",
    "golhey": "assets/Videos/golhey.mp4",
    "hamza": "assets/Videos/hamza.mp4",
    "yay": "assets/Videos/chotiyee.mp4",
    "chotiyay": "assets/Videos/chotiyee.mp4",
    "bariyay": "assets/Videos/bariYe.mp4",

  };

  List<String> _videoQueue = [];
  int _currentVideoIndex = 0;

  @override
  void initState() {
    super.initState();
    _initSpeech();
  }

  String normalizeInput(String input) {
    input = input.trim().toLowerCase();

    bool containsUrdu = RegExp(r'[\u0600-\u06FF]').hasMatch(input);

    if (!containsUrdu) {
      return input;
    }

    // Keep only Urdu letters + spaces
    String cleaned = input.replaceAll(RegExp(r'[^\u0600-\u06FF\s]'), ' ');
    List<String> words =
    cleaned.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return "";

    // Find max Urdu phrase length in dictionary
    final urduKeys = urduToEnglish.keys.toList();
    int maxUrduLen = 1;
    for (var k in urduKeys) {
      int len = k.split(' ').length;
      if (len > maxUrduLen) maxUrduLen = len;
    }

    List<String> englishTokens = [];
    int i = 0;

    // Segment Urdu text into known Urdu phrases and map each to English phrase
    while (i < words.length) {
      bool matched = false;

      for (int len = maxUrduLen; len >= 1; len--) {
        if (i + len <= words.length) {
          String phraseUr = words.sublist(i, i + len).join(" ");
          if (urduToEnglish.containsKey(phraseUr)) {
            englishTokens.add(urduToEnglish[phraseUr]!.toLowerCase());
            i += len;
            matched = true;
            break;
          }
        }
      }

      if (!matched) {
        // Unknown Urdu word → just skip it
        i++;
      }
    }

    return englishTokens.join(" ").trim();
  }

  // ----------------------------------------------------------
  String? findClosestMatch(String input) {
    List<String> phrases = gestureVideos.keys.toList();
    var bestMatch = StringSimilarity.findBestMatch(input, phrases);

    if (bestMatch.bestMatch.rating! >= 0.6) {
      return bestMatch.bestMatch.target;
    }
    return null;
  }

  Future<void> _initSpeech() async {
    await _speechToText.initialize();
  }

  void _toggleListening() async {
    if (isListening) {
      await _speechToText.stop();
      setState(() => isListening = false);
    } else {
      await _speechToText.initialize();
      setState(() => isListening = true);

      String locale = Get.locale?.languageCode == 'ur' ? 'ur-PK' : 'en-US';

      _speechToText.listen(
        localeId: locale,
        onResult: (result) {
          _recognizedText.value = result.recognizedWords;

          if (result.finalResult) {
            _playVideoFromWords(result.recognizedWords);
          }
        },
      );
    }
  }

  // Phrase → videos (fixed segmentation)
  Future<void> _playVideoFromWords(String sentence) async {
    if (sentence.trim().isEmpty) return;

    _recognizedText.value = sentence;
    _textController.clear();

    String normalized = normalizeInput(sentence);
    if (normalized.isEmpty) {
      setState(() {
        _isVideoReady = false;
        uiMessage = "No gesture video exists for this phrase".tr;
      });
      return;
    }

    List<String> words =
    normalized.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();

    _videoQueue = [];
    int i = 0;

    // Find max English phrase length in gestureVideos
    final keys = gestureVideos.keys.toList();
    int maxPhraseLen = 1;
    for (var k in keys) {
      int len = k.split(' ').length;
      if (len > maxPhraseLen) maxPhraseLen = len;
    }

    while (i < words.length) {
      bool matched = false;

      // Try longest exact phrase first (up to maxPhraseLen)
      for (int len = maxPhraseLen; len >= 1; len--) {
        if (i + len <= words.length) {
          String phrase = words.sublist(i, i + len).join(" ");

          // Exact match
          if (gestureVideos.containsKey(phrase)) {
            _videoQueue.add(gestureVideos[phrase]!);
            i += len;
            matched = true;
            break;
          }
        }
      }

      if (!matched) {
        // Fuzzy match ONLY for single words (not full sentences)
        String word = words[i];
        String? corrected = findClosestMatch(word);
        if (corrected != null) {
          _videoQueue.add(gestureVideos[corrected]!);
        }
        i++;
      }
    }

    if (_videoQueue.isNotEmpty) {
      uiMessage = "";
      _currentVideoIndex = 0;
      await _playNextVideo();
    } else {
      setState(() {
        _isVideoReady = false;
        uiMessage = "No gesture video exists for this phrase".tr;
      });
    }
  }
  Future<void> _playNextVideo() async {
    if (_currentVideoIndex >= _videoQueue.length) {
      setState(() => _isVideoReady = false);
      return;
    }

    String nextVideo = _videoQueue[_currentVideoIndex];

    _controller?.dispose();
    _controller = VideoPlayerController.asset(nextVideo);

    await _controller!.initialize();
    setState(() => _isVideoReady = true);

    _controller!.play();

    _controller!.addListener(() async {
      if (_controller!.value.position >= _controller!.value.duration &&
          !_controller!.value.isPlaying) {
        _currentVideoIndex++;
        await _playNextVideo();
      }
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    _textController.dispose();
    super.dispose();
  }

  // UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(
          "Text/Speech to Gesture".tr,
          style: TextStyle(
              color: Colors.green, fontSize: 22, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.green),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _isVideoReady && _controller != null
                  ? AspectRatio(
                aspectRatio: _controller!.value.aspectRatio,
                child: VideoPlayer(_controller!),
              )
                  : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.sign_language,
                      color: Colors.green, size: 80),
                  const SizedBox(height: 10),
                  Text(
                    uiMessage,
                    style: const TextStyle(
                        color: Colors.green,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ---------- Text Field ----------
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _textController,
              decoration: InputDecoration(
                labelText: "Enter text to convert to gesture".tr,
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () =>
                      _playVideoFromWords(_textController.text.trim()),
                ),
              ),
              onSubmitted: (v) => _playVideoFromWords(v.trim()),
            ),
          ),

          const SizedBox(height: 20),

          // ---------- Recognized Text + Mic Button ----------
          Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.green, width: 2),
                    ),
                    child: Obx(
                          () => Text(
                        _recognizedText.value.isEmpty
                            ? "Say something...".tr
                            : _recognizedText.value,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: Colors.green,
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 15),
                FloatingActionButton(
                  backgroundColor: Colors.green,
                  onPressed: _toggleListening,
                  child: Icon(
                    isListening ? Icons.stop : Icons.mic,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
//
//
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:speech_to_text/speech_to_text.dart' as stt;
// import 'package:video_player/video_player.dart';
// import 'package:string_similarity/string_similarity.dart';
//
// class SpeechToGestureScreen extends StatefulWidget {
//   const SpeechToGestureScreen({super.key});
//
//   @override
//   SpeechToGestureScreenState createState() => SpeechToGestureScreenState();
// }
//
// class SpeechToGestureScreenState extends State<SpeechToGestureScreen> {
//   final stt.SpeechToText _speechToText = stt.SpeechToText();
//   final TextEditingController _textController = TextEditingController();
//   final _recognizedText = "".obs;
//
//   bool isListening = false;
//
//   VideoPlayerController? _controller;
//   bool _isVideoReady = false;
//
//   String uiMessage = "Waiting for sign...".tr;
//
//   // Urdu → English Dictionary (keep as-is)
//   final Map<String, String> urduToEnglish = {
//     "ٹھیک": "fine",
//     "کھانا": "food",
//     "اچھا": "good",
//     "ہیلو": "hello",
//     "آپ کیسے ہیں": "how are you",
//     "اپ کیسے ہیں": "how are you",
//     "میں بیمار ہوں": "i am sick",
//     "میں طالب علم ہوں": "i am a student",
//     "میں سائن لینگویج سیکھ رہا ہوں": "i am learning sign language",
//     "میں واپس آؤں گا": "i will be back soon",
//     "آپ کا نام کیا ہے": "what is your name",
//     "اپ کا نام کیا ہے": "what is your name",
//     "کیا": "what",
//     "کون": "who",
//     "کیوں": "why",
//     "ہاں": "yes",
//     "نہیں": "no",
//     "پانی": "water",
//     "شکریہ": "thanks",
//     "باہر": "outside",
//     "اندر": "inside",
//     "خوبصورت": "beautiful",
//     "پیارا": "cute",
//     "ہم": "we",
//     "بھائی": "brother",
//     "بہن": "sister",
//     "میں مدد کیسے کرسکتا ہوں": "how can i help you",
//     "آپ کیسا محسوس کرتے ہیں": "how do you feel",
//     "مجھے اس پر یقین نہیں ہے": "i do not believe this",
//     "مجھے یہ پسند نہیں": "i do not like this",
//     "میں نہیں سمجھا": "i do not understand",
//     "تم": "you",
//     "کیا یہ ٹوٹا ہوا ہے": "is it broken",
//     "ایمبولینس بُلاو": "call the ambulance",
//     "ایمبولینس بُلاوں": "call the ambulance",
//     "کیا یہ سچ ہے": "is it True",
//     "معاف کیجئے": "Excuse me",
//     "چھوئو مت": "Don't Touch",
//     "آپ کا دن اچھا گزرے": "Have a nice day",
//     "صبح": "morning",
//     "بعد": "after",
//     "شام": "evening",
//     "دوبارہ": "again",
//     "عورت": "she",
//     "مرد": "he",
//     "سب": "all",
//     "ہمیشہ": "always",
//     "ایک جیسے": "same",
//     "آو": "come",
//     "چاہیے": "want",
//     "یہ ٹھیک ہے": "it is fine",
//     "ٹھیک ہے": "ok",
//     "تو": "so",
//     "کب": "when",
//     "ا": "alif",
//     "ب": "bay",
//     "پ": "peh",
//     "ت": "tey",
//     "ٹ": "ttey",
//     "ث": "sey",
//     "ج": "jeem",
//     "چ": "chey",
//     "ح": "hha",
//     "خ": "khey",
//     "د": "daal",
//     "ذ": "zaal",
//     "ر": "rey",
//     "ز": "zey",
//     "ژ": "zhey",
//     "ڑ": "arey",
//     "س": "seen",
//     "ش": "sheen",
//     "ص": "suad",
//     "ض": "zuad",
//     "ط": "tuay",
//     "ظ": "zuey",
//     "ع": "ain",
//     "غ": "ghaen",
//     "ف": "fey",
//     "ق": "kaafdots",
//     "ک": "kaaf",
//     "گ": "ghaf",
//     "ل": "laam",
//     "م": "meem",
//     "ن": "noon",
//     "ں": "noonGhunna",
//     "و": "wao",
//     "ہ": "golhey",
//     "ء": "hamza",
//     "ی": "yay",
//     "ے": "bariyay",
//     "ی": "chotiyay",
//   };
//
//   // Gesture Videos (keep as-is)
//   final Map<String, String> gestureVideos = {
//     "fine": "assets/Videos/fine.mp4",
//     "food": "assets/Videos/food.mp4",
//     "good": "assets/Videos/good.mp4",
//     "hello": "assets/Videos/hello1.mp4",
//     "how can i help you": "assets/Videos/howcanIhelpu.mp4",
//     "how do you feel": "assets/Videos/howdoUfeel.mp4",
//     "how are you": "assets/Videos/HowRU1.mp4",
//     "i do not believe this": "assets/Videos/Idontbelievethis.mp4",
//     "i": "assets/Videos/I.mp4",
//     "i do not like this": "assets/Videos/Idontlikethis.mp4",
//     "i do not understand": "assets/Videos/Idontunderstand.mp4",
//     "i am learning sign language": "assets/Videos/IMlearningSignlang.mp4",
//     "i am sick": "assets/Videos/IMsick.mp4",
//     "i am a student": "assets/Videos/IMstudent.mp4",
//     "no": "assets/Videos/no.mp4",
//     "are you deaf": "assets/Videos/RUdeaf.mp4",
//     "are you hungry": "assets/Videos/RUhungry.mp4",
//     "thanks": "assets/Videos/Thanks.mp4",
//     "want": "assets/Videos/want.mp4",
//     "water": "assets/Videos/water.mp4",
//     "what": "assets/Videos/what.mp4",
//     "what is your name": "assets/Videos/WhatURName.mp4",
//     "when": "assets/Videos/when.mp4",
//     "who": "assets/Videos/who.mp4",
//     "why": "assets/Videos/why.mp4",
//     "yes": "assets/Videos/yes.mp4",
//     "you": "assets/Videos/you.mp4",
//     "come": "assets/Videos/come.mp4",
//     "morning": "assets/Videos/morning.mp4",
//     "after": "assets/Videos/after.mp4",
//     "evening": "assets/Videos/evening.mp4",
//     "again": "assets/Videos/again.mp4",
//     "she": "assets/Videos/she.mp4",
//     "he": "assets/Videos/he.mp4",
//     "all": "assets/Videos/all.mp4",
//     "outside": "assets/Videos/outside.mp4",
//     "inside": "assets/Videos/inside.mp4",
//     "it is fine": "assets/Videos/itsFine.mp4",
//     "i will be back soon": "assets/Videos/illBeBacksoon.mp4",
//     "always": "assets/Videos/always.mp4",
//     "cute": "assets/Videos/cute.mp4",
//     "beautiful": "assets/Videos/beautiful.mp4",
//     "ok": "assets/Videos/ok.mp4",
//     "so": "assets/Videos/so.mp4",
//     "sister": "assets/Videos/sister.mp4",
//     "brother": "assets/Videos/brother.mp4",
//     "we": "assets/Videos/we.mp4",
//     "same": "assets/Videos/same.mp4",
//     "is it broken": "assets/Videos/isItBroken.mp4",
//     "call the ambulance": "assets/Videos/callTheAmbulance.mp4",
//     "is it True": "assets/Videos/isItTrue.mp4",
//     "Excuse me": "assets/Videos/excuseMe.mp4",
//     "Don't Touch": "assets/Videos/dontTouch.mp4",
//     "Have a nice day": "assets/Videos/haveAniceDay.mp4",
//     "alif": "assets/Videos/alif.mp4",
//     "bay": "assets/Videos/bey.mp4",
//     "peh": "assets/Videos/pey.mp4",
//     "tey": "assets/Videos/tey.mp4",
//     "ttey": "assets/Videos/ttey.mp4",
//     "sey": "assets/Videos/Sey.mp4",
//     "jeem": "assets/Videos/jeem.mp4",
//     "chey": "assets/Videos/chey.mp4",
//     "hha": "assets/Videos/hey.mp4",
//     "khey": "assets/Videos/khey.mp4",
//     "daal": "assets/Videos/daal.mp4",
//     "zaal": "assets/Videos/zaal.mp4",
//     "rey": "assets/Videos/rey.mp4",
//     "arey": "assets/Videos/arey.mp4",
//     "zey": "assets/Videos/zey.mp4",
//     "zhey": "assets/Videos/zhey.mp4",
//     "seen": "assets/Videos/seen.mp4",
//     "sheen": "assets/Videos/sheen.mp4",
//     "suad": "assets/Videos/suad.mp4",
//     "zuad": "assets/Videos/zuad.mp4",
//     "tuay": "assets/Videos/tuey.mp4",
//     "zuey": "assets/Videos/zuey.mp4",
//     "ain": "assets/Videos/ain.mp4",
//     "ghaf": "assets/Videos/ghaf.mp4",
//     "fey": "assets/Videos/fey.mp4",
//     "kaafdots": "assets/Videos/kaafdots.mp4",
//     "kaaf": "assets/Videos/kaaf.mp4",
//     "gaen": "assets/Videos/gaen.mp4",
//     "laam": "assets/Videos/laam.mp4",
//     "meem": "assets/Videos/meem.mp4",
//     "noon": "assets/Videos/noon.mp4",
//     "noonGhunna": "assets/Videos/noonGhunna.mp4",
//     "wao": "assets/Videos/wao.mp4",
//     "golhey": "assets/Videos/golhey.mp4",
//     "hamza": "assets/Videos/hamza.mp4",
//     "yay": "assets/Videos/chotiyee.mp4",
//     "chotiyay": "assets/Videos/chotiyee.mp4",
//     "bariyay": "assets/Videos/bariYe.mp4",
//   };
//
//   List<String> _videoQueue = [];
//   int _currentVideoIndex = 0;
//
//   @override
//   void initState() {
//     super.initState();
//     _initSpeech();
//   }
//
//   String normalizeInput(String input) {
//     input = input.trim().toLowerCase();
//
//     bool containsUrdu = RegExp(r'[\u0600-\u06FF]').hasMatch(input);
//
//     if (!containsUrdu) {
//       return input;
//     }
//
//     String cleaned = input.replaceAll(RegExp(r'[^\u0600-\u06FF\s]'), ' ');
//     List<String> words =
//     cleaned.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
//     if (words.isEmpty) return "";
//
//     final urduKeys = urduToEnglish.keys.toList();
//     int maxUrduLen = 1;
//     for (var k in urduKeys) {
//       int len = k.split(' ').length;
//       if (len > maxUrduLen) maxUrduLen = len;
//     }
//
//     List<String> englishTokens = [];
//     int i = 0;
//
//     while (i < words.length) {
//       bool matched = false;
//
//       for (int len = maxUrduLen; len >= 1; len--) {
//         if (i + len <= words.length) {
//           String phraseUr = words.sublist(i, i + len).join(" ");
//           if (urduToEnglish.containsKey(phraseUr)) {
//             englishTokens.add(urduToEnglish[phraseUr]!.toLowerCase());
//             i += len;
//             matched = true;
//             break;
//           }
//         }
//       }
//
//       if (!matched) {
//         i++;
//       }
//     }
//
//     return englishTokens.join(" ").trim();
//   }
//
//   String? findClosestMatch(String input) {
//     List<String> phrases = gestureVideos.keys.toList();
//     var bestMatch = StringSimilarity.findBestMatch(input, phrases);
//
//     if (bestMatch.bestMatch.rating! >= 0.6) {
//       return bestMatch.bestMatch.target;
//     }
//     return null;
//   }
//
//   Future<void> _initSpeech() async {
//     await _speechToText.initialize();
//   }
//
//   void _toggleListening() async {
//     if (isListening) {
//       await _speechToText.stop();
//       setState(() => isListening = false);
//     } else {
//       await _speechToText.initialize();
//       setState(() => isListening = true);
//
//       String locale = Get.locale?.languageCode == 'ur' ? 'ur-PK' : 'en-US';
//
//       _speechToText.listen(
//         localeId: locale,
//         onResult: (result) {
//           _recognizedText.value = result.recognizedWords;
//
//           if (result.finalResult) {
//             _playVideoFromWords(result.recognizedWords);
//           }
//         },
//       );
//     }
//   }
//
//   Future<void> _playVideoFromWords(String sentence) async {
//     if (sentence.trim().isEmpty) return;
//
//     _recognizedText.value = sentence;
//     _textController.clear();
//
//     String normalized = normalizeInput(sentence);
//     if (normalized.isEmpty) {
//       setState(() {
//         _isVideoReady = false;
//         uiMessage = "No gesture video exists for this phrase".tr;
//       });
//       return;
//     }
//
//     List<String> words =
//     normalized.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
//
//     _videoQueue = [];
//     int i = 0;
//
//     final keys = gestureVideos.keys.toList();
//     int maxPhraseLen = 1;
//     for (var k in keys) {
//       int len = k.split(' ').length;
//       if (len > maxPhraseLen) maxPhraseLen = len;
//     }
//
//     while (i < words.length) {
//       bool matched = false;
//
//       for (int len = maxPhraseLen; len >= 1; len--) {
//         if (i + len <= words.length) {
//           String phrase = words.sublist(i, i + len).join(" ");
//           if (gestureVideos.containsKey(phrase)) {
//             _videoQueue.add(gestureVideos[phrase]!);
//             i += len;
//             matched = true;
//             break;
//           }
//         }
//       }
//
//       if (!matched) {
//         String word = words[i];
//         String? corrected = findClosestMatch(word);
//         if (corrected != null) {
//           _videoQueue.add(gestureVideos[corrected]!);
//         }
//         i++;
//       }
//     }
//
//     if (_videoQueue.isNotEmpty) {
//       uiMessage = "";
//       _currentVideoIndex = 0;
//       await _playNextVideo();
//     } else {
//       setState(() {
//         _isVideoReady = false;
//         uiMessage = "No gesture video exists for this phrase".tr;
//       });
//     }
//   }
//
//   Future<void> _playNextVideo() async {
//     if (_currentVideoIndex >= _videoQueue.length) {
//       setState(() => _isVideoReady = false);
//       return;
//     }
//
//     String nextVideo = _videoQueue[_currentVideoIndex];
//
//     // Dispose previous controller safely
//     await _controller?.pause();
//     _controller?.dispose();
//
//     _controller = VideoPlayerController.asset(nextVideo);
//
//     await _controller!.initialize();
//     setState(() => _isVideoReady = true);
//
//     _controller!.setLooping(false);
//     _controller!.setVolume(1.0);
//     _controller!.play();
//
//     // Remove previous listeners and add one-time listener
//     _controller!.addListener(() {
//       if (_controller!.value.position >= _controller!.value.duration &&
//           !_controller!.value.isPlaying) {
//         _currentVideoIndex++;
//         _playNextVideo(); // do NOT await
//       }
//     });
//   }
//
//   @override
//   void dispose() {
//     _controller?.dispose();
//     _textController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         centerTitle: true,
//         title: Text(
//           "Text/Speech to Gesture".tr,
//           style: const TextStyle(
//               color: Colors.green, fontSize: 22, fontWeight: FontWeight.bold),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.green),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: Column(
//         children: [
//           Expanded(
//             child: Center(
//               child: _isVideoReady && _controller != null
//                   ? AspectRatio(
//                 aspectRatio: _controller!.value.aspectRatio,
//                 child: VideoPlayer(_controller!),
//               )
//                   : Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   const Icon(Icons.sign_language,
//                       color: Colors.green, size: 80),
//                   const SizedBox(height: 10),
//                   Text(
//                     uiMessage,
//                     style: const TextStyle(
//                         color: Colors.green,
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           const SizedBox(height: 20),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16),
//             child: TextField(
//               controller: _textController,
//               decoration: InputDecoration(
//                 labelText: "Enter text to convert to gesture".tr,
//                 border: const OutlineInputBorder(),
//                 suffixIcon: IconButton(
//                   icon: const Icon(Icons.send),
//                   onPressed: () =>
//                       _playVideoFromWords(_textController.text.trim()),
//                 ),
//               ),
//               onSubmitted: (v) => _playVideoFromWords(v.trim()),
//             ),
//           ),
//           const SizedBox(height: 20),
//           Padding(
//             padding: const EdgeInsets.only(bottom: 20),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: Container(
//                     padding: const EdgeInsets.all(12),
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       border: Border.all(color: Colors.green, width: 2),
//                     ),
//                     child: Obx(
//                           () => Text(
//                         _recognizedText.value.isEmpty
//                             ? "Say something...".tr
//                             : _recognizedText.value,
//                         textAlign: TextAlign.center,
//                         style: const TextStyle(
//                             color: Colors.green,
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold),
//                       ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: 15),
//                 FloatingActionButton(
//                   backgroundColor: Colors.green,
//                   onPressed: _toggleListening,
//                   child: Icon(
//                     isListening ? Icons.stop : Icons.mic,
//                     color: Colors.white,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

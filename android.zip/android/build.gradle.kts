// project-level build.gradle.kts

buildscript {
    repositories {
        google()
//        jcenter()
        mavenCentral()
    }
    dependencies {
        // Use classpath(...) with parentheses and double quotes for Kotlin DSL
        // For kotlin_version, define it as a val within the script or pass it directly
        // The ext property is for Groovy. For Kotlin DSL, you declare variables differently.
        // Let's directly specify the version for plugins here.
        classpath("com.android.tools.build:gradle:8.2.1")
        // Update Kotlin Gradle Plugin version here to 1.9.0 or higher
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.1.0") // <-- Changed this
        classpath("com.google.gms:google-services:4.4.3")
    }
}

allprojects {
    repositories {
        google()
//        jcenter()
        mavenCentral()
    }
}

// These blocks for build directories are correct Kotlin DSL
val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}

subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}